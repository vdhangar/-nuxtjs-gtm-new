module.exports = {
  extends: [
    '@nuxtjs'
  ]
}
