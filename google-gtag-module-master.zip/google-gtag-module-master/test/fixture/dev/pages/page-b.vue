<template>
  <div>
    Page b
  </div>
</template>

<script>
export default {
  head () {
    return {
      title: 'Page B'
    }
  }
}
</script>
