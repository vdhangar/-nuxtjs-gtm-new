<template>
  <div>
    Page A
  </div>
</template>

<script>
export default {
  head () {
    return {
      title: 'Page A'
    }
  }
}
</script>
